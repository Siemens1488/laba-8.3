def calc_stat(listened):
    return f'Вы прослушали {len(listened)} песен.'

print(calc_stat([189, 148, 210, 144, 174, 158, 163, 189, 227, 198]))