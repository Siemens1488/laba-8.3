def print_time(hour, minute, second):
    print(f'На часах {hour.zfill(2)}:{minute.zfill(2)}:{second.zfill(2)}')

print_time('19', '28', '06')